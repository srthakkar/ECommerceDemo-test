﻿
// Angular ajax call function
function AngularAjaxCall($angularHttpObejct, url, postData, httpMethod, callDataType, contentType) {
    if (contentType == undefined)
        contentType = "application/x-www-form-urlencoded;charset=UTF-8";

    if (callDataType == undefined)
        callDataType = "json";

    return $angularHttpObejct({
        method: httpMethod,
        responseType: callDataType,
        url: url,
        crossDomain: true,
        data: postData,
        headers: { 'Content-Type': contentType }

    }).success(function (data, error) {

    }).error(function (data, error) {

        ShowMessage(error);
    });
}

//source: http://stackoverflow.com/questions/20729823/jquery-string-format-issue-with-0
String.prototype.format = function () {
    var str = this;
    for (var i = 0; i < arguments.length; i++) {
        var reg = new RegExp("\\{" + i + "\\}", "gm");
        str = str.replace(reg, arguments[i]);
    }
    return str;
}

function GetSerializedJson(formName) {
    return $.parseJSON($("#" + formName).val());
}

function ShowToaster(type, message, options, callback) {
    toastr.clear();
    toastr.options.closeButton = true;
    toastr.options.timeOut = 1500;
    toastr.options.positionClass = "toast-top-right";
    if (callback != undefined)
        toastr.options.onHidden = callback;

    if (type === "success" && message != undefined && message !== '') {
        toastr.success(message, '', options);
    }
    else if (type === "warning" && message != undefined && message !== '') {
        toastr.warning(message);
    }
    else if (type === "error" && message != undefined && message !== '') {
        toastr.error(message);
    }
    else if (type === "errorDialog" && message != undefined && message !== '') {
        toastr.error(message);
    }
}

function ShowMessage(message, type) {
    if (type != undefined && type === "error")
        toastr.error(message);
    else if (type != undefined && type === "warning")
        toastr.warning(message);
    else
        toastr.success(message);
}

function ShowMessages(data) {
    if (data.IsSuccess != undefined && data.Message != undefined) {
        if (data.IsSuccess && (data.Message != undefined || data.Message != null || data.Message !== '')) {
            ShowMessage(data.Message);
        } else {
            ShowMessage(data.Message, "error");
        }
    }
}

// Check the form errors
function CheckErrors(currentForm, ckEditorRequired, ckEditorText) {

    //var form = $(currentForm)
    //       .removeData("validator") /* added by the raw jquery.validate plugin */
    //       .removeData("unobtrusiveValidation");
    //$.validator.unobtrusive.parse($(currentForm));

    if (!jQuery(currentForm).valid()) {
        $('.field-validation-error.tooltip-danger').tooltip('hide');
        $('.select-validatethis.tooltip-danger').tooltip('hide');
        $('.jcf-class-validatethis.tooltip-danger').tooltip('hide');
        return false;
    }
    return true;
}

//This is required for form validation
$.validator.setDefaults({
    ignore: ":not(.validatealways):hidden",
    showErrors: function (errorMap, errorList) {
        this.defaultShowErrors();
        var allValidation = this.elements();

        // destroy tooltips on valid elements --remove erro from parent row-block
        var validElement = $("." + this.settings.validClass);
        $.each(validElement, function (i, val) {
            if ($(val).parent().hasClass("validate-group")) {

                val = $(val).parent();
            }

            if (!$(val).hasClass('ko-validation')) {
                $(val).removeClass("tooltip-danger").tooltip("destroy").closest('.row-block').removeClass('error');
                $(val).siblings('.select-validatethis').removeClass("tooltip-danger").tooltip("destroy");
                $(val).siblings('.jcf-class-validatethis').removeClass("tooltip-danger").tooltip("destroy");
            }
        });

        // add/update tooltips 
        for (var i = 0; i < errorList.length; i++) {
            var error = errorList[i];

            //$("#" + error.element.id).tooltip();

            $("#" + error.element.id).closest('.row-block').addClass('error');
            $("#" + error.element.id).siblings('.select-validatethis').tooltip("hide");
            if ($("#" + error.element.id).hasClass('jcf-hidden')) {
                if ($("#" + error.element.id).prop('tagName') == 'SELECT') {
                    $("#" + error.element.id).siblings('.select-validatethis')
                        .attr("data-original-title", error.message)
                        .attr("data-html", "true")
                        .addClass("tooltip-danger")
                        .tooltip({ html: true });
                    //.tooltip('show', { html: true });
                } else if ($("#" + error.element.id).attr('type') == 'checkbox') {
                    $("#" + error.element.id).siblings('.jcf-class-validatethis')
                        .attr("data-original-title", error.message)
                        .attr("data-html", "true")
                        .addClass("tooltip-danger")
                        .tooltip({ html: true });//.tooltip('show', { html: true });
                }
            }
            else if ($("#" + error.element.id).parent().hasClass("validate-group")) {
                $("#" + error.element.id).parent(".validate-group")
                    .attr("data-original-title", error.message)
                    .attr("data-html", "true")
                    .addClass("tooltip-danger")
                    .tooltip({ html: true });
            } else {
                $("#" + error.element.id)
                    .attr("data-original-title", error.message)
                    .attr("data-html", "true")
                    .addClass("tooltip-danger")
                    .tooltip({ html: true }); //.tooltip('show', { html: true });//.tooltip({ "html": true });
                //.attr("data-placement", "right")
                //.tooltip({trigger:'click'});
            }
        }
    }
});

/* Common Pager */
var PagerModule = function (sortIndex) {
    var $scope = this;

    $scope.getDataCallback = function () {
        //alert(window.NotImplementedGetDataCallbackFunction);
    };
    $scope.currentPage = 1;
    $scope.pageSize = window.PageSize ? window.PageSize : 10;
    $scope.totalRecords = 0;
    $scope.sortIndex = sortIndex;
    $scope.sortDirection = "DESC";

    $scope.pageChanged = function (newPage) {
        $scope.currentPage = newPage;
        $scope.getDataCallback();
    };

    $scope.TotalPages = function () {
        $scope.TotalPagesCount = parseInt(($scope.totalRecords / $scope.pageSize));
        if (($scope.totalRecords % $scope.pageSize) !== 0) {
            $scope.TotalPagesCount = $scope.TotalPagesCount + 1;
        }
        return $scope.TotalPagesCount;
    };

    //-----------------------------------------CODE FOR SORT-------------------------------------------

    //$scope.predicate = predicate; // coulumn name
    $scope.reverse = true; // asc and desc
    $scope.sortColumn = function (newPredicate) {
        $scope.reverse = ($scope.sortIndex === newPredicate) ? !$scope.reverse : false;
        //$scope.predicate = newPredicate;
        $scope.sortIndex = newPredicate != undefined ? newPredicate : sortIndex;
        $scope.sortDirection = $scope.reverse === true ? "DESC" : "ASC";
        $scope.getDataCallback();
    };

    $scope.selectedPageSize = 5;
    $scope.DefaultPageSize = 5;

    $scope.PageSizeChanged = function (selectedPageSize) {
        $scope.currentPage = 1;
        $scope.pageSize = selectedPageSize;
        $scope.selectedPageSize = selectedPageSize;
        $scope.getDataCallback();
    };

    //-----------------------------------------End CODE FOR SORT-------------------------------------------
};
/*End Common Pager*/