﻿controllers.ProductListController = function ($scope, $http,$timeout) {

    $scope.PagerName = "default";
    $scope.CreateUrl = "/product/addproduct";
    $scope.EditUrl = $scope.CreateUrl + "/";
    $scope.SearchModel = $.parseJSON($("#SearchModel").val());
    $scope.IsPageLoaded = false;

    $scope.Pager = new PagerModule("ProdName");

    $scope.List = [];
    $scope.GetList = function () {
        var pagermodel = {
            searchParams: $scope.SearchModel,
            pageSize: $scope.Pager.pageSize,
            pageIndex: $scope.Pager.currentPage,
            sortIndex: $scope.Pager.sortIndex,
            sortDirection: $scope.Pager.sortDirection
        };
        var jsonData = angular.toJson(pagermodel);
        AngularAjaxCall($http, "/product/getproductlist", jsonData, "POST", "json", "application/json").
            success(function (response, status, headers, config) {
                if (response.IsSuccess) {
                    $scope.IsPageLoaded = true;                   
                    $scope.List = response.Data.Items;
                    $scope.Pager.totalRecords = response.Data.TotalItems;
                }
            });
    };

    $scope.Pager.getDataCallback = $scope.GetList;
    $scope.Pager.getDataCallback();

    $scope.Search = function () {
        $scope.Pager.currentPage = 1;
        $scope.GetList();
    };

};