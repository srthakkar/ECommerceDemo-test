﻿
controllers.AddProductController = function ($scope, $http, $window) {

    $scope.BackToList = "/product/productlist";
    var dataModel = $.parseJSON($("#HiddenModel").val());
    $scope.Product = dataModel.Product;
    $scope.ProductAttributeList = dataModel.ProductAttributeList;
    $scope.ProductCategoryList = dataModel.ProductCategoryList;
    $scope.ProductAttributeLookupList = dataModel.ProductAttributeLookupList;

    $scope.IsEditMode = ($scope.Product !== null) && ($scope.Product.ProductId > 0);

    $scope.SetProductAttribute = function (prodCategoryId) {
        $scope.AttributeList = [];
        $.each($scope.ProductAttributeLookupList, function (i, list) {

            $scope.Attribute = {
            };

            if (list.ProdCatId === Number(prodCategoryId)) {
                $scope.Attribute.ProdCatId = list.ProdCatId;
                $scope.Attribute.AttributeId = list.AttributeId;
                $scope.Attribute.AttributeName = list.AttributeName;

                if ($scope.IsEditMode) {
                    $.each($scope.ProductAttributeList, function (j, productAttr) {
                        if (productAttr.AttributeId === list.AttributeId) {
                            $scope.Attribute.AttributeValue = productAttr.AttributeValue;
                        }
                    });
                } else {
                    $scope.Attribute.AttributeValue = "";
                }

                $scope.AttributeList.push($scope.Attribute);
            }
        });
    };


    if ($scope.IsEditMode) {
        $scope.SetProductAttribute($scope.Product.ProdCatId);
    } else {
        $scope.SetProductAttribute(1);
    }

    $scope.Save = function () {
        if (CheckErrors(jQuery("#AddForm"))) {
            var param = {};
            param.Product = $scope.Product;
            param.ProductAttributeList = $scope.AttributeList;
            var jsonData = angular.toJson(param);

            AngularAjaxCall($http, "/product/saveproduct", jsonData, "POST", "json", "application/json").
                success(function (response) {

                    if (response.IsSuccess) {
                        $window.location = $scope.BackToList;
                    } else {
                        // handle error 
                    }
                });
        }
    };

    $scope.ProductCategoryChanged = function (productCategoryId) {
        $scope.SetProductAttribute(productCategoryId);
    };


};
