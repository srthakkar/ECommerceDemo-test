﻿using System;
using System.Net;
using System.Web;
using System.Web.Mvc;
using TestDemo.Infrastructure.Library;

namespace TestDemo.Controllers
{
    public class BaseController : Controller
    {
        protected override void OnException(ExceptionContext filterContext)
        {
            try
            {
                var httpContext = filterContext.HttpContext.ApplicationInstance.Context;
                
                filterContext.ExceptionHandled = true;
                filterContext.HttpContext.Response.Clear();
                filterContext.HttpContext.Response.TrySkipIisCustomErrors = true;

                if (filterContext.HttpContext.Request.IsAjaxRequest())
                {
                    filterContext.HttpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    filterContext.Result = new JsonResult
                    {
                        JsonRequestBehavior = JsonRequestBehavior.AllowGet,
                        Data = new
                        {
                            filterContext.Exception.Message
                        }
                    };
                }
                else
                {
                    filterContext.Result = new ViewResult
                    {
                        ViewName = "~/views/shared/error.cshtml",

                    };
                    ViewBag.ServerError = filterContext.Exception.Message;
                }


                if (filterContext.Exception.GetType() == typeof(HttpException))
                {
                    HttpException exception = filterContext.Exception as HttpException;
                    if (exception != null) filterContext.HttpContext.Response.StatusCode = exception.GetHttpCode();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected ActionResult RenderView(ServiceResponse response, string viewName = "")
        {
            if (!response.IsSuccess) return View("error", response.Message);
            if (response.Data != null)
            {
                return !string.IsNullOrEmpty(viewName) ? View(viewName, response.Data) : View(response.Data);
            }
            return !string.IsNullOrEmpty(viewName) ? View(viewName) : View();
        }
    }
}