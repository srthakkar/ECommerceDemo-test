﻿using System.Web.Mvc;
using TestDemo.Infrastructure.DataProvider;
using TestDemo.Infrastructure.IDataProvider;
using TestDemo.Models.ViewModel;

namespace TestDemo.Controllers
{
    public class ProductController : BaseController
    {
        private IProductDataProvider _productDataProvider;

        [HttpGet]
        public ActionResult AddProduct(long? id)
        {
            _productDataProvider = new ProductDataProvider();
            return RenderView(_productDataProvider.GetProductDetails(id));
        }

        [HttpPost]
        public JsonResult SaveProduct(ProductDetails productDetails)
        {
            _productDataProvider = new ProductDataProvider();
            return Json(_productDataProvider.SaveProduct(productDetails));
        }

        [HttpGet]
        public ActionResult ProductList()
        {
            _productDataProvider = new ProductDataProvider();
            return View("productlist", new ProductSearch());
        }

        [HttpPost]
        public JsonResult GetProductList(ProductSearch searchParams, int pageSize = 10, int pageIndex = 1,
                                     string sortIndex = "", string sortDirection = "")
        {
            _productDataProvider = new ProductDataProvider();
            return Json(_productDataProvider.GetProductList(searchParams, pageSize, pageIndex, sortIndex, sortDirection));
        }
    }
}