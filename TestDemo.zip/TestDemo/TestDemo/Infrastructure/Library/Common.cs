﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace TestDemo.Infrastructure.Library
{
    public class Common
    {
        public static string SerializeObject<T>(T objectData)
        {
            string defaultJson = JsonConvert.SerializeObject(objectData);
            return defaultJson;
        }

        public string SerializePartialObject<T>(T objectData)
        {
            string defaultJson = JsonConvert.SerializeObject(objectData, (Newtonsoft.Json.Formatting)Formatting.Indented,
                                  new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            return defaultJson;
        }

        public static T DeserializeObject<T>(string json)
        {
            T obj = default(T);
            obj = JsonConvert.DeserializeObject<T>(json);
            return obj;
        }

        public static string GetPageSizeList()
        {
            List<PageSizeList> list = new List<PageSizeList>();
            List<int> pageSizeList = string.IsNullOrEmpty(ConfigSettings.PageSizeList)
                                                         ? null
                                                         : ConfigSettings.PageSizeList.Split(',')
                                                                         .Select(s => Convert.ToInt32(s))
                                                                         .ToList();

            if (pageSizeList != null)
                list.AddRange(pageSizeList.Select(pagesize => new PageSizeList
                {
                    PageSize = pagesize
                }));
            return SerializeObject(list);
        }

        public static class ConfigSettings
        {
            public static readonly string PageSizeList = ConfigurationManager.AppSettings["PageSizeList"];
            public static readonly string PageSize = ConfigurationManager.AppSettings["PageSize"];
        }
    }

    public class ServiceResponse//<T>
    {
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
        public object Data { get; set; }


    }


}