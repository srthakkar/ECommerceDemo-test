﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestDemo.Infrastructure.Library
{
    public class PagerModel
    {
        public string PagerName { get; set; }
    }

    public class PageSizeList
    {
        public int PageSize { get; set; }
    }
}