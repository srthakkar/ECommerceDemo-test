﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestDemo.Infrastructure.Library;
using TestDemo.Models.ViewModel;

namespace TestDemo.Infrastructure.IDataProvider
{
    interface IProductDataProvider
    {
        ServiceResponse GetProductDetails(long? id);
        ServiceResponse SaveProduct(ProductDetails product);
        ServiceResponse GetProductList(ProductSearch searchParams, int pageSize, int pageIndex, string sortIndex, string sortDirection);
    }
}
