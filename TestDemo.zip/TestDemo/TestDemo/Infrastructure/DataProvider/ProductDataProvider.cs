﻿using System;
using System.Collections.Generic;
using System.Linq;
using TestDemo.Infrastructure.IDataProvider;
using TestDemo.Infrastructure.Library;
using TestDemo.Models;
using TestDemo.Models.ViewModel;

namespace TestDemo.Infrastructure.DataProvider
{
    public class ProductDataProvider : BaseDataProvider, IProductDataProvider
    {

        public ServiceResponse GetProductDetails(long? id)
        {
            ServiceResponse response = new ServiceResponse();
            try
            {
                ProductDetails details =
                    GetMultipleEntity<ProductDetails>("GetProductDetails",
                    new List<SearchValueData>
                    {
                        new SearchValueData { Name = "ProductId", Value = Convert.ToString(id) }
                    });
                response.IsSuccess = true;
                response.Data = details;
            }
            catch (Exception e)
            {
                response.Message = e.Message;
            }
            return response;
        }

        public ServiceResponse GetProductList(ProductSearch searchParams, int pageSize, int pageIndex, string sortIndex, string sortDirection)
        {
            ServiceResponse response = new ServiceResponse();
            try
            {
                List<SearchValueData> searchList = new List<SearchValueData>
                    {
                        new SearchValueData {Name = "ProdName", Value = searchParams.ProdName}
                };
                response = GetPageRecord<ProductList>(pageSize, pageIndex, sortIndex, sortDirection, searchList);
            }
            catch (Exception e)
            {
                response.Message = e.Message;
            }
            return response;
        }

        public ServiceResponse SaveProduct(ProductDetails productDetails)
        {
            ServiceResponse response = new ServiceResponse();
            bool isEditMode = productDetails.Product.ProductId > 0;
            try
            {
                List<string> productAttributeList = productDetails.ProductAttributeList.Select(attribute =>
                    attribute.AttributeId + "|" +
                    attribute.AttributeValue
                ).ToList();

                TransactionResult result = GetEntity<TransactionResult>("SaveProduct", new List<SearchValueData>
                {
                    new SearchValueData {Name = "IsEditMode", Value = Convert.ToString(isEditMode) },
                    new SearchValueData{Name = "ProductId" ,Value=Convert.ToString(productDetails.Product.ProductId)},
                    new SearchValueData{Name = "ProdCatId" ,Value=Convert.ToString(productDetails.Product.ProdCatId)},
                    new SearchValueData{Name = "ProdName" ,Value=Convert.ToString(productDetails.Product.ProdName)},
                    new SearchValueData{Name = "ProdDescription" ,Value=Convert.ToString(productDetails.Product.ProdDescription)},
                    new SearchValueData {Name = "ProductAttributeList",Value =  string.Join(",", productAttributeList)}
                });
                if (result.TransactionResultId > 0)
                {
                    response.IsSuccess = true;
                    response.Message = (isEditMode) ? "" : "";
                }
                else
                {
                    response.Message = "Error while saving data in database " + result.ErrorMessage;
                }
            }
            catch (Exception e)
            {
                response.Message = "Something went wrong " + e.Message;
                return response;
            }
            return response;
        }
    }
}