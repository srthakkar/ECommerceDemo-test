﻿using PetaPoco;
using System.ComponentModel.DataAnnotations;
using TestDemo.Resources;

namespace TestDemo.Models.Entity
{
    [TableName("Product")]
    [PrimaryKey("ReferralReasonId")]
    public class Product
    {
        public long ProductId { get; set; }

        [Required(ErrorMessageResourceName = "FieldRequired", ErrorMessageResourceType = typeof(Resource))]
        public int ProdCatId { get; set; }

        [Required(ErrorMessageResourceName = "FieldRequired", ErrorMessageResourceType = typeof(Resource))]
        public string ProdName { get; set; }

        public string ProdDescription { get; set; }


    }
}