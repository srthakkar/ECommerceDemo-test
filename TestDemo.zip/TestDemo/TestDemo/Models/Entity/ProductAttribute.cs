﻿using PetaPoco;
using System.ComponentModel.DataAnnotations;
using TestDemo.Resources;

namespace TestDemo.Models.Entity
{
    [PetaPoco.TableName("ProductAttribute")]
    public class ProductAttribute
    {
        [Required(ErrorMessageResourceName = "FieldRequired", ErrorMessageResourceType = typeof(Resource))]
        public long ProductId { get; set; }
        [Required(ErrorMessageResourceName = "FieldRequired", ErrorMessageResourceType = typeof(Resource))]
        public int AttributeId { get; set; }
        public string AttributeValue { get; set; }

        [Ignore]
        public string AttributeName { get; set; }
    }
}