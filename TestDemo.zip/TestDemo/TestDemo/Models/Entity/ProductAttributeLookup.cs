﻿using PetaPoco;

namespace TestDemo.Models.Entity
{
    [TableName("ProductAttributeLookup")]
    [PrimaryKey("AttributeId")]
    public class ProductAttributeLookup
    {
        public int AttributeId { get; set; }
        public int ProdCatId { get; set; }
        public string AttributeName { get; set; }
    }
}