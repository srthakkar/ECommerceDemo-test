﻿using PetaPoco;

namespace TestDemo.Models.Entity
{
    [TableName("ProductCategory")]
    [PrimaryKey("ProdCatId")]
    public class ProductCategory
    {
        public int ProdCatId { get; set; }
        public string CategoryName { get; set; }
    }
}