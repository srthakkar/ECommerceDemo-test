﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestDemo.Models
{
    public class TransactionResult
    {
        public int TransactionResultId { get; set; }
        public string ErrorMessage { get; set; }
        public long TablePrimaryId { get; set; }
    }
}