﻿using System.Collections.Generic;
using TestDemo.Models.Entity;

namespace TestDemo.Models.ViewModel
{

    public class ProductDetails
    {
        public ProductDetails()
        {
            Product = new Product();
            ProductAttributeList = new List<ProductAttribute>();
            ProductCategoryList = new List<ProductCategory>();
            ProductAttributeLookupList = new List<ProductAttributeLookup>();
        }
        public Product Product { get; set; }
        public List<ProductAttribute> ProductAttributeList { get; set; }
        public List<ProductCategory> ProductCategoryList { get; set; }
        public List<ProductAttributeLookup> ProductAttributeLookupList { get; set; }

    }
}