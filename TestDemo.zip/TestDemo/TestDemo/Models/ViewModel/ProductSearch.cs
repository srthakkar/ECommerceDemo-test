﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TestDemo.Models.ViewModel
{
    public class ProductSearch
    {
        public string ProdName { get; set; }
    }
}