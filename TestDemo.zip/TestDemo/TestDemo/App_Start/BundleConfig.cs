﻿using System.Web.Optimization;

namespace TestDemo
{
    public static class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            BundleTable.EnableOptimizations = false;
            BundleTable.Bundles.IgnoreList.Clear(); // apparently, IgnoreList included .min.js in debug
            BundleTable.Bundles.IgnoreList.Ignore(".intellisense.js", OptimizationMode.Always);
            BundleTable.Bundles.IgnoreList.Ignore("-vsdoc.js", OptimizationMode.Always);
            BundleTable.Bundles.IgnoreList.Ignore(".debug.js", OptimizationMode.Always);

            bundles.Add(new StyleBundle("~/Content/css").Include(
                "~/content/bootstrap.css",
                "~/content/Site.css",
                "~/assets/css/common.css"
                ));

            bundles.Add(new ScriptBundle("~/common/js").Include(
                "~/assets/js/sitejs/angular.js",
                 "~/assets/js/sitejs/dirPagination.js",
                "~/assets/js/viewjs/app.js",
                "~/assets/js/viewjs/common.js"
            ));

            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                "~/scripts/jquery-1.10.2.js",
                "~/scripts/modernizr-2.6.2.js",
                "~/scripts/bootstrap.js",
                "~/assets/js/sitejs/jquery.unobtrusive-ajax.js",
                "~/assets/js/sitejs/jquery.validate*"
                ));
            
            bundles.Add(new ScriptBundle("~/assets/js/viewjs/product/productlist").Include(                
               "~/assets/js/viewjs/product/productlist.js"
               ));

            bundles.Add(new ScriptBundle("~/assets/js/viewjs/product/addproduct").Include(
               "~/assets/js/viewjs/product/addproduct.js"
               ));

        }
    }
}